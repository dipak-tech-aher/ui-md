export const Properties = {
  INDEXED_DB_NAME: "carsDB",
  API_ENDPOINT:
    // process.env.REACT_APP_API_ENDPOINT || "https://cars-serviceapi-nonprod.azurewebsites.net/api",
    process.env.REACT_APP_API_ENDPOINT || "https://localhost:7091/api",
  TEMPLATE_MASTER_API: "/templatemaster/Templates",
  TEMPLATE_MASTER_VARIABLES_API: "/templatemaster/TemplateVariables",
};
// 