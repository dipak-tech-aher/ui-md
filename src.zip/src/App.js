import React, { lazy, useContext } from "react";
import {
  Navigate,
  BrowserRouter as Router,
  Routes,
  Route,
} from "react-router-dom";
import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import FallbackLoader from "./common/FallbackLoader";
import { Canvas } from "./components/templateDesigner_ex/canvas/Canvas";
import { ViewTemplateVariables } from "./components/ViewTemplateVariables";
import { Test } from "./components/templateDesigner_ex/canvas/Test";

const CreateTemplate = lazy(() => import("./components/CreateTemplate"));
const AccessControl = lazy(() => import("./common/AccessControl"));
const NotFound = lazy(() => import("./common/NotFound"));

function App() {
  return (
    <Router>
      <React.Suspense fallback={<FallbackLoader />}>
        <Routes>
          <Route
            path="/create-template"
            element={<AccessControl component={CreateTemplate} />}
          />
          <Route
            path="/view-template/:templateId"
            element={<AccessControl component={CreateTemplate} />}
          />
          <Route
            path="/canvas"
            element={<AccessControl component={Canvas} />}
          />
          <Route
            path="/Test"
            element={<AccessControl component={Test} />}
          />
          <Route
            path="/view-template-variables"
            element={<AccessControl component={ViewTemplateVariables} />}
          />
          <Route path="*" element={<AccessControl component={NotFound} />} />
        </Routes>
      </React.Suspense>
    </Router>
  );
}

export default App;
