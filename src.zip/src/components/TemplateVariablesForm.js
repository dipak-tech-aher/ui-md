import { Formik, Form, Field, ErrorMessage } from "formik";

export const TemplateVariablesForm = (props) => {
  const { initialFormValues, validationSchema, wordForm, templateTypes } =
    props?.data;
  console.log("initialFormValues----->", initialFormValues);
  console.log("wordForm----->", wordForm);
  const { handleFillWordForm } = props?.handlers;
  return (
    <Formik
      initialValues={initialFormValues}
      validationSchema={validationSchema}
      onSubmit={(values) => {
        handleFillWordForm(values);
      }}
    >
      {({ errors, touched }) => (
        <Form className="form-of-dynamic-variables">
          
          {wordForm.map((field, index) => (
            <div key={index} className="form-group mb-3">
              {(field.inputType?.includes("{") &&
                JSON.parse(field?.inputType)?.dataType === "checkbox") ||
              field.inputType === "checkbox" ? (
                <div className="form-check">
                  <label
                    style={{ float: "left" }}
                    className="form-check-label"
                    htmlFor={field.label}
                  >
                    {field.label}
                    <Field
                      type="checkbox"
                      name={field.label}
                      className="form-check-input"
                      id={field.label}
                    />
                  </label>
                </div>
              ) : field.inputType?.includes("{") &&
                ["text", "number"].includes(
                  JSON.parse(field?.inputType)?.dataType
                ) ? (
                <>
                  <label htmlFor={field.label} style={{ float: "left" }}>
                    {field.label}
                  </label>
                  <Field
                    name={field.label}
                    type={JSON.parse(field?.inputType)?.dataType}
                    // value={JSON.parse(field?.inputType)?.values?.[0]?.value}
                    className="form-control "
                  />
                </>
              ) : ["text", "number"].includes(field.inputType) ? (
                <>
                  <label htmlFor={field.label} style={{ float: "left" }}>
                    {field.label}
                  </label>
                  <Field
                    name={field.label}
                    type={field.inputType}
                    className="form-control "
                  />
                </>
              ) : field.inputType?.includes("{") &&
                JSON.parse(field?.inputType)?.dataType === "select" ? (
                <>
                  <label style={{ float: "left" }} htmlFor={field.label}>
                    {field.label}
                  </label>
                  <Field
                    id={field.label}
                    name={field.label}
                    as="select"
                    className="form-control"
                  >
                    <option value="" disabled selected>
                      Select an option
                    </option>
                    {JSON.parse(field?.inputType)?.values?.map((ele) => (
                      <option key={ele?.value} value={ele?.value}>
                        {ele?.label}
                      </option>
                    ))}
                  </Field>
                </>
              ) : field.inputType === "select" ? (
                <>
                  <label style={{ float: "left" }} htmlFor={field.label}>
                    {field.label}
                  </label>
                  <Field
                    id={field.label}
                    name={field.label}
                    as="select"
                    className="form-control"
                  >
                    <option value="" disabled selected>
                      Select an option
                    </option>
                    {templateTypes?.map((ele) => (
                      <option key={ele?.value} value={ele?.value}>
                        {ele?.label}
                      </option>
                    ))}
                  </Field>
                </>
              ) : (
                <>
                  <label style={{ float: "left" }} htmlFor={field.label}>
                    {field.label}
                  </label>
                  <Field
                    name={field.label}
                    type={field.inputType}
                    className="form-control"
                  />
                </>
              )}
              <ErrorMessage
                name={field.label}
                component="div"
                className="text-danger"
              />
            </div>
          ))}
          {wordForm?.length > 0 && (
            <div>
              <button type="submit" className="btn btn-primary">
                Save
              </button>
            </div>
          )}
        </Form>
      )}
    </Formik>
  );
};
