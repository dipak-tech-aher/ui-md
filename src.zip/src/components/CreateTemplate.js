import React, { useEffect, useRef, useState } from "react";
import { StepOne } from "./stepForms/StepOne";
import { useParams } from "react-router-dom";
import { Properties } from "../Properties";
import { StepTwo } from "./stepForms/StepTwo";
import { get } from "../common/hooks/useApi";

export default function CreateTemplate() {
  const { templateId } = useParams();
  const [step, setStep] = useState(1);
  const [templateData, setTemplateData] = useState();
  const [templateFormValues, setTemplateFormValues] = useState();

  const handleFillTemplateForm = (formValues) => {
    setTemplateFormValues(formValues);
    setStep((prev) => prev + 1);
  };

  useEffect(() => {
    if (templateId) {
      const GetTemplateByTemplateIDUrl = `${Properties?.API_ENDPOINT}${Properties?.TEMPLATE_MASTER_API}/GetTemplateByTemplateID?templateID=${templateId}`;
      get(GetTemplateByTemplateIDUrl)
        .then((res) => {
          setTemplateData(res?.data?.value);
        })
        .catch((err) => {
          console.log("err---->", err);
        });
    }
  }, [templateId]);

  return (
    <>
      {step === 1 && (
        <StepOne
          data={{ templateData, templateId, templateFormValues, step }}
          handlers={{ setTemplateFormValues, handleFillTemplateForm }}
        />
      )}
      {step === 2 && (
        <StepTwo
          data={{ templateData, templateId, templateFormValues, step }}
          handlers={{ setStep }}
        />
      )}
    </>
  );
}
