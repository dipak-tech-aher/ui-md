import React, { useEffect, useRef, useState } from "react";
import { JsonToMjml } from "easy-email-core";
import htmlDocx from "html-docx-js/dist/html-docx";
import { saveAs } from "file-saver";
import swal from "sweetalert";
import { post, put, get } from "../../common/hooks/useApi";
import { Properties } from "../../Properties";
import { useParams } from "react-router-dom";
import EmailTemplateDesigner from "../EmailTemplateDesigner";

const mjmlBrowser = require("mjml-browser");

export const StepTwo = (props) => {
  const { templateId, templateData, templateFormValues, step } = props?.data;
  const { setStep } = props?.handlers;
  const [subject, setSubject] = useState("Welcome to Template Creation");
  const [editorJson, setEditorJson] = useState();
  const [editorHtml, setEditorHtml] = useState("");
  const [mergeTags, setMergeTags] = useState({
    name: "tableName",
    mergeTags: [],
  });

  const [isNewTemplateVariable, setIsNewTemplateVariable] = useState(false);

  const emailEditorRef = useRef(null);

  const onReady = () => {
    console.log("called");
    emailEditorRef?.current?.editor?.loadDesign();
  };

  useEffect(() => {
    if (templateData) {
      setEditorJson(JSON.parse(templateData?.template_Content));
      setEditorHtml(templateData?.template_Html);
    }
  }, [templateData]);

  const getTemplateVariables = async (templateContent) => {
    console.log(
      "mergeTags?.mergeTags?.mergeTags------->",
      mergeTags?.mergeTags
    );
    const formJsonArray = [];
    const traverse = (obj) => {
      for (let key in obj) {
        if (typeof obj[key] === "string") {
          mergeTags?.mergeTags.forEach((tag) => {
            if (obj[key]?.includes(`{{${tag?.name}}}`)) {
              let formJson = {
                label: tag?.name,
                inputType: tag?.value,
                value: "",
              };
              formJsonArray.push(formJson);
            }
          });
        } else if (typeof obj[key] === "object" && obj[key] !== null) {
          traverse(obj[key]);
        }
      }
    };

    traverse(templateContent);

    console.log("formJsonArray---xxx-->", formJsonArray);

    return formJsonArray;
  };

  const getEmailContent = async (values) => {
    console.log("templateFormValues------------>", templateFormValues);
    console.log("values------------>", values);
    if (
      templateFormValues?.template_Name !== "" &&
      templateFormValues?.template_Type !== ""
    ) {
      try {
        const templateVariables = await getTemplateVariables(values?.content);
        const data = {
          mode: "production",
          data: values.content,
          context: values.content,
          dataSource: null,
        };
        const mjmlString2 = JsonToMjml(data);
        const { json, html } = mjmlBrowser(mjmlString2);
        const jsonContent = values.content;
        const htmlContent = html;
        setEditorJson(jsonContent);
        setEditorHtml(htmlContent);
        const requestBody = {
          template_Name: templateFormValues?.template_Name,
          team_Id: 10,
          template_Type: templateFormValues?.template_Type,
          template_Content: JSON.stringify(jsonContent),
          template_Html: htmlContent,
          template_Parameters: templateVariables
            ? JSON.stringify(templateVariables)
            : "test",
          template_path: "/",
          is_Active: true,
        };
        console.log("requestBody----->", JSON.stringify(requestBody));
        const isCached = false;
        const isFormData = false;
        if (templateId) {
          requestBody.template_Id = templateId;
          requestBody.template_Name = templateData?.template_Name;
          requestBody.template_Type = templateData?.template_Type;
          put(
            `${Properties?.API_ENDPOINT}${Properties?.TEMPLATE_MASTER_API}`,
            requestBody,
            isCached,
            isFormData
          )
            .then((res) => {
              const docx = htmlDocx.asBlob(htmlContent, {
                orientation: "landscape",
              });
              saveAs(docx, "edited.docx");
              swal({
                title: "Success!",
                text: "Template saved successfully!",
                icon: "success",
                button: "Ok",
              });
              window.top.postMessage(
                { type: "REDIRECT", url: "/view-templates" },
                "*"
              );
            })
            .catch((err) => {
              console.log("err-->", err);
            })
            .finally(() => {});
        } else {
          post(
            `${Properties?.API_ENDPOINT}${Properties?.TEMPLATE_MASTER_API}`,
            requestBody,
            isCached,
            isFormData
          )
            .then((res) => {
              const docx = htmlDocx.asBlob(htmlContent, {
                orientation: "landscape",
              });
              saveAs(docx, "edited.docx");
              swal({
                title: "Success!",
                text: "Template saved successfully!",
                icon: "success",
                button: "Ok",
              });
              window.top.postMessage(
                { type: "REDIRECT", url: "/view-templates" },
                "*"
              );
            })
            .catch((err) => {
              console.log("err-->", err);
            })
            .finally(() => {});
        }
      } catch (error) {
        console.log("err---->", error);
      }
    }
  };

  const handleFillWordForm = (formValues) => {
    // console.log("formValues0----->", formValues);
    if (templateId) {
      // console.log("iside view----", JSON.parse(templateData?.template_Content));
      const dynamicJsonWithData = customRenderMergeTagsWithData(
        JSON.parse(templateData?.template_Content),
        formValues
      );
      // console.log(
      //   "dynamicJsonWithData----------->",
      //   JSON.stringify(dynamicJsonWithData)
      // );
      setEditorJson(dynamicJsonWithData);
    } else {
      console.log("iside create----");

      const dynamicJsonWithData = customRenderMergeTagsWithData(
        editorJson,
        formValues
      );
      setEditorJson(dynamicJsonWithData);
    }
    setSubject("Welcome to Template Updation");
  };

  const customRenderMergeTagsWithData = (json, mergeTags) => {
    const traverse = (obj) => {
      for (let key in obj) {
        if (typeof obj[key] === "string") {
          Object.keys(mergeTags).forEach((tag) => {
            const regex = new RegExp(`{{${tag}}}`, "g");
            console.log("obj[key]------------>", obj[key]);
            console.log("mergeTags[tag]------------>", mergeTags[tag]);
            obj[key] = obj[key].replace(
              regex,
              `${
                tag?.includes("checkbox") && mergeTags[tag]
                  ? "☒"
                  : tag?.includes("checkbox") && !mergeTags[tag]
                  ? "☐"
                  : mergeTags[tag]
              }`
            );
            console.log("obj[key]------------->", obj[key]);
          });
        } else if (typeof obj[key] === "object" && obj[key] !== null) {
          traverse(obj[key]);
        }
      }
    };
    traverse(json);
    console.log("json------->", JSON.stringify(json));
    return json;
  };

  useEffect(() => {
    const GetTemplateVariablesUrl = `${Properties?.API_ENDPOINT}${Properties?.TEMPLATE_MASTER_VARIABLES_API}`;
    get(GetTemplateVariablesUrl)
      .then((res) => {
        setMergeTags({
          name: "tableName",
          mergeTags: res?.data,
        });
      })
      .catch((err) => {
        console.log("err---->", err);
      });
  }, [isNewTemplateVariable]);

  return (
    <>
      <EmailTemplateDesigner
        onReady={onReady}
        onSubmit={getEmailContent}
        editorJson={editorJson}
        mergeTags={{ mergeTags }}
        handleFillWordForm={handleFillWordForm}
        subject={subject}
        templateData={templateData}
        isNewTemplateVariable={isNewTemplateVariable}
        setIsNewTemplateVariable={setIsNewTemplateVariable}
        setStep={setStep}
      />
    </>
  );
};
