import React, { useEffect, useState } from "react";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";

export const StepOne = (props) => {
  const { templateId, templateData, step } = props?.data;
  const { handleFillTemplateForm } = props?.handlers;
  const [templateForm, setTemplateForm] = useState([
    {
      label: "Template name",
      name: "template_Name",
      inputType: "text",
    },
    {
      label: "Template type",
      name: "template_Type",
      inputType: "select",
    },
  ]);

  const [templateTypes, setTemplateTypes] = useState([
    {
      value: "Overturn",
      label: "Overturn",
    },
    {
      value: "Uphold",
      label: "Uphold",
    },
    {
      value: "Partial",
      label: "Partial",
    },
  ]);

  const templateValidationSchema = Yup.object().shape(
    templateForm.reduce((schema, field) => {
      schema[field.name] = Yup.string().required(`${field.label} is required`);
      return schema;
    }, {})
  );

  const initialtemplateFormValues = templateForm.reduce((values, field) => {
    if (templateId && templateData) {
      Object.keys(templateData)?.map((ele) => {
        if (ele === field.name) {
          console.log("templateData[ele]-------->",field.name,'-->', templateData[ele]);
          values[field.name] = templateData[ele];
        }
      });
    } else {
      values[field.name] = "";
    }
    return values;
  }, {});

  return (
    <div className="d-flex justify-content-center align-items-center">
      <div className="w-50">
        <label className="heading-step-form">Create Template</label>
        {console.log("initialtemplateFormValues---->", initialtemplateFormValues)}
        <Formik
        enableReinitialize
          initialValues={initialtemplateFormValues}
          validationSchema={templateValidationSchema}
          onSubmit={(values) => {
            handleFillTemplateForm(values);
          }}
        >
          {({ errors, touched }) => (
            <Form className="row m-1">
              <div className="w-100">
                {templateForm.map((field, index) => (
                  <div className="form-group col-md-12 p-2" key={index}>
                    <label htmlFor={field.name} className="dynamic-form-label">
                      {field.label}
                    </label>
                    {field.inputType === "text" && (
                      <Field
                        name={field.name}
                        type={field.inputType}
                        className="form-control"
                      />
                    )}
                    {field.inputType === "select" && (
                      <Field
                        name={field.name}
                        as="select"
                        className="form-control"
                      >
                        <option value="" disabled>
                          Select an option
                        </option>
                        {templateTypes?.map((ele) => (
                          <option key={ele.value} value={ele.value}>
                            {ele.label}
                          </option>
                        ))}
                      </Field>
                    )}
                    <ErrorMessage
                      name={field.name}
                      component="div"
                      className="text-danger"
                    />
                  </div>
                ))}
                <div className="form-group col-md-12 p-2 d-flex justify-content-end">
                  <button type="submit" className="btn btn-primary">
                    Next
                  </button>
                </div>
              </div>
            </Form>
          )}
        </Formik>
      </div>
    </div>
  );
};
