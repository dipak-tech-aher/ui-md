import React, { useState } from "react";
import { Modal, Button, Form } from "react-bootstrap";
import { Formik, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import * as XLSX from "xlsx";
import { post } from "../common/hooks/useApi";
import { Properties } from "../Properties";
import { useNavigate } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faDownload } from "@fortawesome/free-solid-svg-icons";
import axios from "axios";
import { saveAs } from "file-saver";

export const TemplateVariableModal = (props) => {
  const [predefinedValues, setPredefinedValues] = useState();
  const navigate = useNavigate();
  const { handleClose, setIsNewTemplateVariable } = props?.handlers;
  const { templateVariableModal, isNewTemplateVariable } = props?.data;
  const [dataType, setDataType] = useState("");
  const validationSchema = Yup.object({
    templateKey: Yup.string().required("Template Key is required"),
    variableValue: Yup.string().required("Data type is required"),
    variablePredefinedValue: Yup.string(),
    file: Yup.mixed().nullable().notRequired(),
  });

  const templateDataTypes = [
    { value: "text", label: "text" },
    { value: "number", label: "number" },
    { value: "date", label: "date" },
    { value: "select", label: "select" },
    { value: "checkbox", label: "checkbox" },
  ];

  const handleOnFileChange = (excelFile) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      const data = new Uint8Array(event.target.result);
      const workbook = XLSX.read(data, { type: "array" });
      const sheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[sheetName];
      const jsonData = XLSX.utils.sheet_to_json(worksheet);
      console.log("jsonData---->", jsonData);
      const values = jsonData?.map((ele) => {
        return {
          label: ele?.template_variable_predefined_values,
          value: ele?.template_variable_predefined_values,
        };
      });
      setPredefinedValues(values);
    };
    reader.readAsArrayBuffer(excelFile);
  };

  const handleSubmitForm = (values) => {
    const isCached = false;
    const isFormData = false;

    console.log("values-------->", values);
    console.log("values-------->", values?.variablePredefinedValue);

    let arr = [];
    const splited = values?.variablePredefinedValue?.split(",");
    for (let val of splited) {
      arr.push({ label: val, value: val });
    }
    console.log("predefinedValues-------->", predefinedValues);
    let variableValue = {
      dataType: values?.variableValue,
      values: predefinedValues ?? arr,
    };
    console.log("variableValue---->", variableValue);
    // You can now send jsonData to your API or handle it as needed
    post(
      `${Properties?.API_ENDPOINT}${Properties?.TEMPLATE_MASTER_VARIABLES_API}`,
      {
        templateKey: values?.templateKey,
        variableValue: JSON.stringify(variableValue),
      },
      isCached,
      isFormData
    )
      .then((res) => {
        setIsNewTemplateVariable(!isNewTemplateVariable);
        handleClose();
      })
      .catch((err) => {
        console.log("err-->", err);
      });
  };

  const handleRedirectToViewAllTemplateVariables = () => {
    navigate("/view-template-variables");
  };

  const downloadFile = async () => {
    try {
      const response = await axios.get("/predefined_values.xlsx", {
        responseType: "blob",
      });
      const blob = new Blob([response.data], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });
      saveAs(blob, "downloaded_file.xlsx");
    } catch (error) {
      console.error("Error downloading the file", error);
    }
  };

  const handleBulkuploadView = (e) => {
    setDataType(e?.target?.value);
  };
  return (
    <Modal show={templateVariableModal} onHide={handleClose}>
      <Formik
        initialValues={{
          templateKey: "",
          variableValue: "",
          variablePredefinedValue: "",
          file: null,
        }}
        validationSchema={validationSchema}
        onSubmit={(values) => {
          handleSubmitForm(values);
        }}
      >
        {({ handleSubmit, setFieldValue }) => (
          <Form onSubmit={handleSubmit}>
            <Modal.Header closeButton>
              <Modal.Title>
                Add template Variables&nbsp;&nbsp;
                <Button
                  type="button"
                  variant="primary"
                  onClick={handleRedirectToViewAllTemplateVariables}
                >
                  View All Variables
                </Button>
              </Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <div className="form-group">
                <label htmlFor="templateKey">Variable Name</label>
                <Field
                  name="templateKey"
                  type="text"
                  className="form-control"
                />
                <ErrorMessage
                  name="templateKey"
                  component="div"
                  className="text-danger"
                />
              </div>
              <div className="form-group">
                <label htmlFor="variableValue">Data Type</label>
                <Field
                  onChange={(event) => {
                    setFieldValue("variableValue", event.target.value);
                    handleBulkuploadView(event);
                  }}
                  value={dataType}
                  name="variableValue"
                  as="select"
                  className="form-control"
                >
                  <option value="" disabled>
                    Select an option
                  </option>
                  {templateDataTypes.map((ele) => (
                    <option key={ele.value} value={ele.value}>
                      {ele.label}
                    </option>
                  ))}
                </Field>
                <ErrorMessage
                  name="variableValue"
                  component="div"
                  className="text-danger"
                />
              </div>
              <div className="form-group">
                <label htmlFor="variablePredefinedValue">
                  Value (please enter values by comma seperated)
                </label>
                <Field
                  name="variablePredefinedValue"
                  as="textarea"
                  className="form-control"
                />
                <ErrorMessage
                  name="variablePredefinedValue"
                  component="div"
                  className="text-danger"
                />
              </div>
              {dataType === "select" && (
                <>
                  <div className="form-group">
                    <span className="pointer" onClick={downloadFile}>
                      <FontAwesomeIcon icon={faDownload} />
                      Click here Download the excel format to upload the bulk
                      values
                    </span>
                  </div>
                  <div className="form-group">
                    <label htmlFor="file">Upload Values</label>
                    <input
                      id="file"
                      name="file"
                      type="file"
                      className="form-control"
                      onChange={(event) => {
                        setFieldValue("file", event.currentTarget.files[0]);
                        handleOnFileChange(event.currentTarget.files[0]);
                      }}
                    />
                    <ErrorMessage
                      name="file"
                      component="div"
                      className="text-danger"
                    />
                  </div>
                </>
              )}
            </Modal.Body>
            <Modal.Footer>
              <Button variant="secondary" onClick={handleClose}>
                Close
              </Button>
              <Button type="submit" variant="primary">
                Save Changes
              </Button>
            </Modal.Footer>
          </Form>
        )}
      </Formik>
    </Modal>
  );
};
