import React, { useState } from "react";
import { Modal, Button, Form } from "react-bootstrap";
import { Formik, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import { post } from "../common/hooks/useApi";
import { Properties } from "../Properties";
import { useNavigate } from "react-router-dom";

export const TemplateVariableModal = (props) => {
  const navigate = useNavigate();
  const { handleClose, setIsNewTemplateVariable } = props?.handlers;
  const { templateVariableModal, isNewTemplateVariable } = props?.data;
  const validationSchema = Yup.object({
    templateKey: Yup.string().required("Templat eKey is required"),
    variableValue: Yup.string().required("Variable Value is required"),
  });

  const templateDataTypes = [
    {
      value: "text",
      label: "text",
    },
    {
      value: "number",
      label: "number",
    },
    {
      value: "date",
      label: "date",
    },
    {
      value: "select",
      label: "select",
    },
    {
      value: "checkbox",
      label: "checkbox",
    },
  ];

  const handleSubmitForm = (values) => {
    const isCached = false;
    const isFormData = false;
    post(
      `${Properties?.API_ENDPOINT}${Properties?.TEMPLATE_MASTER_VARIABLES_API}?templateKey=${values?.templateKey}&variableValue=${values?.variableValue}`,
      isCached,
      isFormData
    )
      .then((res) => {
        setIsNewTemplateVariable(!isNewTemplateVariable);
        handleClose();
      })
      .catch((err) => {
        console.log("err-->", err);
      })
      .finally(() => {});
  };

  const handleRedirectToViewAllTemplateVariables = () => {
    navigate("/view-template-variables");
  };
  return (
    <Modal show={templateVariableModal} onHide={handleClose}>
      <Formik
        initialValues={{ templateKey: "", variableValue: "" }}
        validationSchema={validationSchema}
        onSubmit={(values) => {
          handleSubmitForm(values);
        }}
      >
        {({ handleSubmit }) => (
          <Form onSubmit={handleSubmit}>
            <Modal.Header closeButton>
              <Modal.Title>
                Add template Variables&nbsp;&nbsp;
                <Button
                  type="button"
                  variant="primary"
                  onClick={() => handleRedirectToViewAllTemplateVariables()}
                >
                  View All Variables
                </Button>
              </Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <div className="form-group">
                <label htmlFor="templateKey">Variable Name</label>
                <Field
                  name="templateKey"
                  type="text"
                  className="form-control"
                />
                <ErrorMessage
                  name="templateKey"
                  component="div"
                  className="text-danger"
                />
              </div>
              <div className="form-group">
                <label htmlFor="variableValue">Data Type</label>
                <Field
                  name="variableValue"
                  as="select"
                  className="form-control"
                >
                  <option value="" disabled selected>
                    Select an option
                  </option>
                  {templateDataTypes?.map((ele) => (
                    <option value={ele?.value}>{ele?.label}</option>
                  ))}
                </Field>
                <ErrorMessage
                  name="variableValue"
                  component="div"
                  className="text-danger"
                />
              </div>
            </Modal.Body>
            <Modal.Footer>
              <Button variant="secondary" onClick={handleClose}>
                Close
              </Button>
              <Button type="submit" variant="primary">
                Save Changes
              </Button>
            </Modal.Footer>
          </Form>
        )}
      </Formik>
    </Modal>
  );
};
