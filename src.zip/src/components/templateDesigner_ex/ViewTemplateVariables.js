export const ViewTemplateVariables = () => {
  return (
    <>
      <iframe src="http://localhost:3000/view-template-variables" style={{ width: '100%', height: '900px' }}/>
    </>
  );
};
