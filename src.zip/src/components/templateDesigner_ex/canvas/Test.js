import React from 'react';
import { BlockManager, BasicType } from 'easy-email-core';
import { EmailEditor, EmailEditorProvider } from 'easy-email-editor';

export const Test = () => {
  // Define your table block with additional rows and columns
  const tableBlock = BlockManager.getBlockByType(BasicType.TABLE)?.create({
    data: {
      columns: 4, // Number of columns
      rows: 5,    // Number of rows
    },
  });

  // Initial values for the email content
  const initialValues = {
    subject: 'Welcome to Easy-email',
    subTitle: 'Nice to meet you!',
    content: BlockManager.getBlockByType(BasicType.PAGE)?.create({
      children: [tableBlock],
    }),
  };

  return (
    <EmailEditorProvider data={initialValues} height={'calc(100vh - 72px)'} autoComplete dashed={false}>
      {({ values }) => (
        <EmailEditor />
      )}
    </EmailEditorProvider>
  );
};