import React, { useState } from 'react';
import { DndProvider, useDrag, useDrop } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import { Rnd } from 'react-rnd';

const ItemTypes = {
  CONTROL: 'control',
};

const DraggableControl = ({ type, children }) => {
  const [{ isDragging }, drag] = useDrag(() => ({
    type: ItemTypes.CONTROL,
    item: { type },
    collect: (monitor) => ({
      isDragging: !!monitor.isDragging(),
    }),
  }));

  return (
    <div ref={drag} style={{ opacity: isDragging ? 0.5 : 1 }}>
      {children}
    </div>
  );
};

const DroppableCanvas = ({ onDrop, controls }) => {
  const [, drop] = useDrop(() => ({
    accept: ItemTypes.CONTROL,
    drop: (item, monitor) => {
      const offset = monitor.getClientOffset();
      onDrop(item.type, offset);
    },
  }));

  return (
    <div ref={drop} style={{ width: '100%', height: '100%', border: '1px solid black' }}>
      {controls.map((control, index) => (
        <Rnd
          key={index}
          default={{
            x: control.x,
            y: control.y,
            width: control.width,
            height: control.height,
          }}
          bounds="parent"
        >
          {control.type === 'textbox' && <input type="text" placeholder="Textbox" />}
          {control.type === 'richtext' && <textarea placeholder="Rich Text Area" />}
          {control.type === 'table' && (
            <TableComponent control={control} />
          )}
        </Rnd>
      ))}
    </div>
  );
};

const TableComponent = ({ control }) => {
  const [tableData, setTableData] = useState(control.tableData || {
    headers: ['Header 1', 'Header 2'],
    rows: [['Row 1 Col 1', 'Row 1 Col 2']],
  });

  const addRow = () => {
    setTableData((prevData) => ({
      ...prevData,
      rows: [...prevData.rows, Array(prevData.headers.length).fill('')],
    }));
  };

  const deleteRow = (index) => {
    setTableData((prevData) => ({
      ...prevData,
      rows: prevData.rows.filter((_, i) => i !== index),
    }));
  };

  const addColumn = () => {
    setTableData((prevData) => ({
      ...prevData,
      headers: [...prevData.headers, `Header ${prevData.headers.length + 1}`],
      rows: prevData.rows.map((row) => [...row, '']),
    }));
  };

  const deleteColumn = (index) => {
    setTableData((prevData) => ({
      ...prevData,
      headers: prevData.headers.filter((_, i) => i !== index),
      rows: prevData.rows.map((row) => row.filter((_, i) => i !== index)),
    }));
  };

  return (
    <div>
      <table>
        <thead>
          <tr>
            {tableData.headers.map((header, index) => (
              <th key={index}>{header}</th>
            ))}
            <th>
              <button onClick={addColumn}>Add Column</button>
            </th>
          </tr>
        </thead>
        <tbody>
          {tableData.rows.map((row, rowIndex) => (
            <tr key={rowIndex}>
              {row.map((cell, cellIndex) => (
                <td key={cellIndex}>{cell}</td>
              ))}
              <td>
                <button onClick={() => deleteRow(rowIndex)}>Delete Row</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <button onClick={addRow}>Add Row</button>
    </div>
  );
};

export const Canvas = () => {
  const [controls, setControls] = useState([]);

  const handleDrop = (type, offset) => {
    setControls((prevControls) => [
      ...prevControls,
      { type, x: offset.x, y: offset.y, width: 100, height: 50, tableData: null },
    ]);
  };

  const generateHTML = () => {
    const html = controls.map((control) => {
      if (control.type === 'textbox') {
        return `<input type="text" style="position: absolute; left: ${control.x}px; top: ${control.y}px; width: ${control.width}px; height: ${control.height}px;" />`;
      }
      if (control.type === 'richtext') {
        return `<textarea style="position: absolute; left: ${control.x}px; top: ${control.y}px; width: ${control.width}px; height: ${control.height}px;"></textarea>`;
      }
      if (control.type === 'table') {
        const tableHTML = control.tableData
          ? `<table style="position: absolute; left: ${control.x}px; top: ${control.y}px; width: ${control.width}px; height: ${control.height}px;">
              <thead>
                <tr>${control.tableData.headers.map((header) => `<th>${header}</th>`).join('')}</tr>
              </thead>
              <tbody>
                ${control.tableData.rows.map((row) => `<tr>${row.map((cell) => `<td>${cell}</td>`).join('')}</tr>`).join('')}
              </tbody>
            </table>`
          : '';
        return tableHTML;
      }
      return '';
    }).join('');
    console.log(html);
  };

  return (
    <DndProvider backend={HTML5Backend}>
      <div style={{ display: 'flex' }}>
        <div style={{ width: '30%', padding: '10px', borderRight: '1px solid black' }}>
          <DraggableControl type="textbox">
            <input type="text" placeholder="Textbox" />
          </DraggableControl>
          <DraggableControl type="richtext">
            <textarea placeholder="Rich Text Area" />
          </DraggableControl>
          <DraggableControl type="table">
            <table>
              <thead>
                <tr>
                  <th>Header 1</th>
                  <th>Header 2</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>Row 1 Col 1</td>
                  <td>Row 1 Col 2</td>
                </tr>
              </tbody>
            </table>
          </DraggableControl>
        </div>
        <div style={{ width: '70%', padding: '10px' }}>
          <DroppableCanvas onDrop={handleDrop} controls={controls} />
          <button onClick={generateHTML}>Generate HTML</button>
        </div>
      </div>
    </DndProvider>
  );
};