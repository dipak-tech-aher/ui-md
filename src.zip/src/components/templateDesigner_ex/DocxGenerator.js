import React, { useState } from "react";
import { saveAs } from "file-saver";
import PizZip from "pizzip";
import Docxtemplater from "docxtemplater";

const DocxGenerator = () => {
  const [file, setFile] = useState(null);
  const [name, setName] = useState("");

  const handleFileChange = (event) => {
    setFile(event.target.files[0]);
  };

  const handleNameChange = (event) => {
    setName(event.target.value);
  };

  const generateDocument = () => {
    if (!file) {
      alert("Please upload a DOCX template file.");
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const content = event.target.result;
        const zip = new PizZip(content);
        const doc = new Docxtemplater(zip, {
          paragraphLoop: true,
          linebreaks: true,
        });

        // Set the template variables
        console.log("name----->", name);
        doc.render({
          Choose_diagnosis: name,
          DOS: name,
          Choose_Vein: name,
          Code: name,
          Side: name,
          Procedure: name,
          Policy: name,
        });

        const blob = doc.getZip().generate({
          type: "blob",
          mimeType:
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        });

        // Save the generated document
        saveAs(blob, "output.docx");
      } catch (error) {
        console.error("Error generating document:", error);
        alert(
          "An error occurred while generating the document. Please check the console for details."
        );
      }
    };

    reader.readAsBinaryString(file);
  };

  return (
    <div>
      <h1>Upload DOCX Template and Generate Document</h1>
      <input type="file" accept=".docx" onChange={handleFileChange} />
      <input
        type="text"
        placeholder="Enter name"
        value={name}
        onChange={handleNameChange}
      />
      <button onClick={generateDocument}>Generate Document</button>
    </div>
  );
};

export default DocxGenerator;
