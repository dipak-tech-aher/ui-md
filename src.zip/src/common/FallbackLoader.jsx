import React from 'react';

const FallbackLoader = () => {

  return <div className="loading-spinner"></div>
};

export default FallbackLoader;
