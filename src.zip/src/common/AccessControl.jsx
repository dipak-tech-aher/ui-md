import { useAuth } from "react-oidc-context";
import React, { useEffect, useRef } from "react";
import { Navigate } from "react-router-dom";

export default function AccessControl({  component: Component, ...rest }){
  const auth = useAuth();
  const timeoutRef = useRef(null); // Explicitly type the useRef

  // useEffect(() => {
  //   const handleAccessTokenExpiring = async () => {
  //     try {
  //       await auth.signinSilent();
  //     } catch (error) {
  //       console.error("Silent sign-in failed", error);
  //     }
  //   };

  //   const scheduleTokenRenewal = () => {
  //     if (auth.user && auth.user.expires_in) {
  //       // Calculate the time until the token expires and subtract 5 minutes (300 seconds)
  //       const timeUntilExpiry = auth.user.expires_in * 1000; // Convert to milliseconds
  //       const timeUntilRenewal = timeUntilExpiry - 5 * 60 * 1000; // Subtract 5 minutes in milliseconds

  //       // Schedule the silent sign-in
  //       if (timeUntilRenewal > 0) {
  //         timeoutRef.current = setTimeout(() => {
  //           handleAccessTokenExpiring();
  //         }, timeUntilRenewal);
  //       }
  //     }
  //   };

  //   scheduleTokenRenewal();

  //   // Add event listeners
  //   auth.events.addAccessTokenExpiring(handleAccessTokenExpiring);

  //   // Cleanup event listeners and timeout on unmount
  //   return () => {
  //     if (timeoutRef.current) {
  //       clearTimeout(timeoutRef.current);
  //     }
  //     auth.events.removeAccessTokenExpiring(handleAccessTokenExpiring);
  //   };
  // }, [auth.events, auth.user, auth.signinSilent]);

  // if (!auth?.isAuthenticated) {
    return <div className="App"><Component key={new Date().getTime()} {...rest} /></div>;
  // } else if (!auth?.isLoading && !auth?.isAuthenticated) {
  //   return <Navigate to="/signout" />;
  // }
  // return <></>;
};