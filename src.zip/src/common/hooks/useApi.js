import { useState, useEffect } from "react";
import axios from "axios";
import { Properties } from "../../Properties";
import { getFromDB, setToDB } from "../utils/indexedDBUtils";

export const useApi = (url, jwtToken) => {
  const [data, setData] = useState([]);
  useEffect(() => {
    fetch(url, {
      credentials: "include",
      mode: "cors",
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET,POST,OPTIONS,DELETE,PUT",
        Authorization: `Bearer ${jwtToken}`,
      },
    })
      .then((res) => {
        return res.json();
      })
      .then((result) => {
        setData(result);
      });
  }, []);
  return data;
};

export const generateToken = async () => {
  try {
    const httpClient = axios.create({
      withCredentials: true, // Use cookies and default credentials
    });

    return new Promise((resolve, reject) => {
      httpClient
        .get(`${Properties?.API_ENDPOINT}/Auth/Authenticate`)
        .then((response) => {
          resolve(response.data);
        })
        .catch((error) => {
          console.error("There was an error making the request:", error);
          reject(error);
        });
    });
  } catch (error) {
    console.error("API call failed:", error);
    throw error;
  } finally {
  }
};

export const isCacheExpired = (cacheEntry) => {
  const { cacheTime, maxAge } = cacheEntry;
  return Date.now() - cacheTime > maxAge * 1000;
};

export const post = async (
  apiEndpoint,
  requestBody,
  token,
  dispatch,
  isCached,
  isFormData = false
) => {
  try {
    if (isCached) {
      const CACHE_KEY = JSON.stringify(requestBody);
      const cachedResponse = await getFromDB(CACHE_KEY);
      if (cachedResponse && !isCacheExpired(cachedResponse)) {
        return Promise.resolve(cachedResponse.data);
      } else {
        return postNetworkCall(
          apiEndpoint,
          requestBody,
          token,
          dispatch,
          isFormData,
          isCached
        );
      }
    } else {
      return postNetworkCall(
        apiEndpoint,
        requestBody,
        token,
        dispatch,
        isFormData,
        isCached
      );
    }
  } catch (error) {
    console.error("API call failed:", error);
    throw error;
  }
};

const postNetworkCall = async (
  apiEndpoint,
  requestBody,
  token,
  dispatch,
  isFormData,
  isCached
) => {
  if (!token && !apiEndpoint?.includes("/clinical/")) {
    const tokenData = await generateToken();
    token = tokenData?.access;
  }
  const headers = {
    "Content-Type": isFormData ? "multipart/form-data" : "application/json",
    Authorization: `Bearer ${token}`,
  };

  if (!token) {
    delete headers.Authorization;
  }

  return new Promise((resolve, reject) => {
    axios
      .post(apiEndpoint, requestBody, { headers })
      .then((response) => {
        const resp = response?.data ? response?.data : response;
        if (isCached) {
          const cacheEntry = {
            data: response.data,
            cacheTime: Date.now(),
            maxAge: 60, // 120 minutes in seconds
          };
          const CACHE_KEY = JSON.stringify(requestBody);
          setToDB(CACHE_KEY, cacheEntry);
        }
        resolve(resp);
      })
      .catch((error) => {
        reject(error);
      });
  });
};

export const get = async (
  apiEndpoint,
  requestBody,
  token,
  dispatch,
  isCached,
  isFormData = false
) => {
  try {
    if (isCached) {
      const CACHE_KEY = JSON.stringify(requestBody);
      const cachedResponse = await getFromDB(CACHE_KEY);
      if (cachedResponse && !isCacheExpired(cachedResponse)) {
        return Promise.resolve(cachedResponse.data);
      } else {
        return getNetworkCall(
          apiEndpoint,
          requestBody,
          token,
          dispatch,
          isFormData,
          isCached
        );
      }
    } else {
      console.log('apiEndpoint---------->',apiEndpoint)
      return getNetworkCall(
        apiEndpoint,
        requestBody,
        token,
        dispatch,
        isFormData,
        isCached
      );
    }
  } catch (error) {
    console.error("API call failed:", error);
    throw error;
  }
};

const getNetworkCall = async (
  apiEndpoint,
  requestBody,
  token,
  dispatch,
  isFormData,
  isCached
) => {
  if (!token && !apiEndpoint?.includes("/clinical/")) {
    const tokenData = await generateToken();
    token = tokenData?.access;
  }
  const headers = {
    "Content-Type": isFormData ? "multipart/form-data" : "application/json",
    Authorization: `Bearer ${token}`,
  };

  if (!token) {
    delete headers.Authorization;
  }

  return new Promise((resolve, reject) => {
    axios
      .get(apiEndpoint, { headers, params: requestBody })
      .then((response) => {
        const resp = response?.data ? response?.data : response;
        if (isCached) {
          const cacheEntry = {
            data: response.data,
            cacheTime: Date.now(),
            maxAge: 7200, // 120 minutes in seconds
          };
          const CACHE_KEY = JSON.stringify(requestBody);
          setToDB(CACHE_KEY, cacheEntry);
        }
        resolve(resp);
      })
      .catch((error) => {
        reject(error);
      });
  });
};

export const put = async (
  apiEndpoint,
  requestBody,
  token,
  dispatch,
  isCached,
  isFormData = false
) => {
  try {
    if (isCached) {
      const CACHE_KEY = JSON.stringify(requestBody);
      const cachedResponse = await getFromDB(CACHE_KEY);
      if (cachedResponse && !isCacheExpired(cachedResponse)) {
        return Promise.resolve(cachedResponse.data);
      } else {
        return putNetworkCall(
          apiEndpoint,
          requestBody,
          token,
          dispatch,
          isFormData,
          isCached
        );
      }
    } else {
      return putNetworkCall(
        apiEndpoint,
        requestBody,
        token,
        dispatch,
        isFormData,
        isCached
      );
    }
  } catch (error) {
    console.error("API call failed:", error);
    throw error;
  }
};

const putNetworkCall = async (
  apiEndpoint,
  requestBody,
  token,
  dispatch,
  isFormData,
  isCached
) => {
  if (!token && !apiEndpoint?.includes("/clinical/")) {
    const tokenData = await generateToken();
    token = tokenData?.access;
  }
  const headers = {
    "Content-Type": isFormData ? "multipart/form-data" : "application/json",
    Authorization: `Bearer ${token}`,
  };

  if (!token) {
    delete headers.Authorization;
  }

  return new Promise((resolve, reject) => {
    axios
      .put(apiEndpoint, requestBody, { headers })
      .then((response) => {
        const resp = response?.data ? response?.data : response;
        if (isCached) {
          const cacheEntry = {
            data: response.data,
            cacheTime: Date.now(),
            maxAge: 60, // 120 minutes in seconds
          };
          const CACHE_KEY = JSON.stringify(requestBody);
          setToDB(CACHE_KEY, cacheEntry);
        }
        resolve(resp);
      })
      .catch((error) => {
        reject(error);
      });
  });
};

export default {
  useApi,
  get,
  put,
  post,
};