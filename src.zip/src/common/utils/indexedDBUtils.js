import { openDB } from 'idb';

const DB_NAME = 'carsTemplateMasterDB';
const STORE_NAME = 'cacheStore';

const initDB = async () => {
  return openDB(DB_NAME, 1, {
    upgrade(db) {
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME);
      }
    },
  });
};

export const getFromDB = async (key) => {
  const db = await initDB();
  return db.get(STORE_NAME, key);
};

export const setToDB = async (key, value) => {
  const db = await initDB();
  return db.put(STORE_NAME, value, key);
};
